def Output( count, total ) :
    # count為一個list，包含特別獎、特獎、頭獎、二獎、三獎、四獎、五獎、六獎和沒中獎的次數
    # total為中獎總金額
    print('特別獎：', count[0])
    print('特獎：', count[1])
    print('頭獎：', count[2])
    print('二獎：', count[3])
    print('三獎：', count[4])
    print('四獎：', count[5])
    print('五獎：', count[6])
    print('六獎：', count[7])
    print('沒中獎：', count[8])
    print(total)

