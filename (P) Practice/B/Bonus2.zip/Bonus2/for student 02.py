def Input(num) :
  num = input("Please input the binary : ")

def Output( decimal, decimal_reverse ,heximal ) :
  print("Decimal: ", decimal)
  print("Decimal reverse: ", decimal_reverse)
  print("Heximal: ", heximal)